const mongoose = require('mongoose');
const Discord = require("discord.js")
const { Intents } = require("discord.js")

const config = require("./config.json");
const emailsList = require("./emails.json")


const client = new Discord.Client({
    intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES],
})

client.login(config.token)

//Init Bot
client.on("ready", () => {
    console.log("BOT ON!")
    iniciarConexaoDataBase()
})

//Add Member
client.on("guildMemberAdd", (member) => {
    console.log("BEMVINDO")
    const welcomeChannel = member.guild.channels.cache.find(channel => channel.id == config.channelId)
    welcomeChannel.send(`Olá ${member.user}! - Bem vindo ao .........................`) //chanel
    member.send("Bem vindo!") //privado
})

//Verificação Email
client.on("messageCreate", (message) => {
    let mensagemConteudo = message.content
    let conteudoSplit = mensagemConteudo.split(' ')

    if(conteudoSplit[0] == "!verificar"){
        let isEmailValido = validarEmailTurma(conteudoSplit[1])

        if(isEmailValido){
            // Adicionar Tag|Cargo
            adicionarCargoTurma(message, isEmailValido.turma)

            message.reply({
                content: "Email validado! Agora você pode ter acesso liberado! Lembrando que o acesso é INTRANSFERÍVEL!"
            })
        }else{
            message.reply({
                content: "O email informado não possui registro ou já foi adicionado ao servidor"
            })
        }
    }

    if(conteudoSplit[0] == "!server-status"){
        if(message.channel.id == config.channelId){
            message.reply("Servidor: " + message.channel.name + " funcionando normalmente.")
        }
    }

    if(conteudoSplit[0] == "!remove_roles"){
        if(message.channel.id == config.channelId){
            message.reply("Comando executado com sucesso!")
        }
        message.member.roles.remove(config.tag_Turma3)
        message.member.roles.remove(config.tag_Turma4)
        message.member.roles.remove(config.tag_Turma5)
        message.member.roles.remove(config.tag_Turma6)
        message.member.roles.remove(config.tag_Turma7)
        message.member.roles.remove(config.tag_Alun)
        console.log("cargos removido")
    }

    if(conteudoSplit[0] == "!update"){
        if(message.channel.id == config.channelId){
            message.reply("Atualizando...")
        }

        alterarStatusValidacaoEmail(conteudoSplit[1])
    }
})


//--------------------------------------------------------------------------------------------//
//Validação de Emails
//--------------------------------------------------------------------------------------------//


async function validarEmailTurma(emailParam){
    let emails = await buscarListaGeralEmails()
    
    for (let i = 0; i< emails.length; i++) {
        if(emailParam == emails[i].email){
            if(emails[i].isValidado){
                console.log("é validado viu")
                console.log(emails[i])
            }else{
                console.log("é validado não, pode fazer1")
                console.log(emails[i])
                // return emails[i]
            }
        }
    }
    return false
}

function adicionarCargoTurma(message, turma){
    let tag_alun = config.tag_Alun
    let tag_turma_4 = config.tag_Turma4
    let tag_turma_5 = config.tag_Turma5
    let tag_turma_6 = config.tag_Turma6
    let tag_turma_7 = config.tag_Turma7

    console.log("Turma: " + turma)

    if(turma == 4){
        message.member.roles.add(tag_turma_4)
        console.log("Adicionado a turma 04")
    }

    if(turma == 5){
        message.member.roles.add(tag_turma_5)
        console.log("Adicionado a turma 05")
    }

    if(turma == 6){
        message.member.roles.add(tag_turma_6)
        console.log("Adicionado a turma 06")
    }
    if(turma == 7){
        message.member.roles.add(tag_turma_7)
        console.log("Adicionado a turma 07")
    }

    message.member.roles.add(tag_alun)

    console.log("Tags adicionadas com sucesso!")
}



//--------------------------------------------------------------------------------------------//
// Operações no banco de dados
//--------------------------------------------------------------------------------------------//

async function iniciarConexaoDataBase(){
    const connection = await mongoose.connect('mongodb+srv://discordbot:lkLf729KOkcP8E2S@discorddb.dasg2.mongodb.net/email_bot_verify?retryWrites=true&w=majority').then(() => {
        console.log("Conexão ao Database realizada com sucesso!")
    }).catch((err) => {
        console.log("Não foi possível estabelecar conexão com o Database")
    })
}

async function buscarListaGeralEmails(){
    const Schema = mongoose.Schema
    const ObjectId = Schema.ObjectId;
    
    const Emails = new Schema({
        _id: ObjectId,
        id: Number,
        email: String,
        turma: Number,
        isValidado: Boolean
    })

    const MyModel = mongoose.model('list_emails', Emails)
    const instance = await MyModel.find()
    return instance
}

async function alterarStatusValidacaoEmail(emailValidado){
    const filter = { email: emailValidado };
    const update = { isValidado: true };

    const modelEmails = obterModelEmails()

    const MyModel = mongoose.model('list_emails', modelEmails)
    let doc = await MyModel.findOneAndUpdate(filter, update)
    console.log(doc)
}


function obterModelEmails(){
    const Schema = mongoose.Schema
    const ObjectId = Schema.ObjectId

    const Emails = new Schema({
        _id: ObjectId,
        id: Number,
        email: String,
        turma: Number,
        isValidado: Boolean
    })

    return Emails
}




